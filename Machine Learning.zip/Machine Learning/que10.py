x = int(input("Enter x: "))

if x > 0:
    print(f"{x} is positive")
elif x < 0:
    print(f"{x} is negative")
else:
    print(f"{x} is zero")

for i in range(0, x):
    print(f"{i} ")
