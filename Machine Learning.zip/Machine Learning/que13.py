import pandas as pd
from sklearn import linear_model
import math

df = pd.read_csv("homeprices.csv")

median_bedrooms = math.floor(df.bedrooms.median())
df.bedrooms = df.bedrooms.fillna(median_bedrooms)

reg = linear_model.LinearRegression()
reg.fit(df[['area', 'bedrooms', 'age']], df.price)

val1 = reg.predict([[3000, 3, 40]])
val2 = reg.predict([[2500, 4, 5]])

print(f"For instance with values [3000, 3, 40]: {val1}")
print(f"For instance with values [2500, 4, 5]: {val2}")
