import numpy as np

#que1:
n = int(input("Enter rows: "))
m = int(input("Enter columns: "))
arr = np.random.randint((n,m))
print(arr)
