import numpy as np

def nthRowCol():
    r = int(input("Enter which row you want displayed: "))
    c = int(input("Enter which column you want displayed: "))
    return r, c


m = int(input("Enter no. of rows: "))
n = int(input("Enter no. of columns: "))

mat1 = np.random.randint(1, 100, size=(m, n))
mat2 = np.random.randint(1, 100, size=(m, n))
print(mat1)
print(mat2)

print("Adding both matrices...")
result = np.add(mat1, mat2)
print(result)
row, col = nthRowCol()
print(result[row])
print(result[:, col])
    
print("Subtracting second from first...")
result = np.subtract(mat1, mat2)
print(result)
row, col = nthRowCol()
print(result[row])
print(result[:, col])
    
print("Multiplying matrices...")
result = np.multiply(mat1, mat2)
print(result)
row, col = nthRowCol()
print(result[row])
print(result[:, col])
        
