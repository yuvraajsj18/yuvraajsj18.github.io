#Que1:
list1 = ["M", "na", "i", "Ke"]
list2 = ["y", "me", "s", "lly"]
print("list1 :",list1)
print("list2 :",list2)
l = [list1[i]+list2[i] for i in range(0,len(list1))]
print("new list: ",l)


#Que2:
l1 = ["Mike", "", "Emma", "Kelly", "", "Brad"]
print("\nlist1 :",l1)
l2 = [i for i in l1 if i != ""]
print("new list: ",l2)


#Que3:
list1 = ["a", "b", ["c", ["d", "e", ["f", "g"], "k"], "l"], "m", "n"]
sub_list = ["h", "i", "j"]
print("\nlist1 :",list1)
print("sublist :",sub_list)
list1[2][1][2].extend(sub_list)
print("new list: ",list1)

#Que4:
str1 = "P@#yn26at^&i5ve"
print("\nstring: ",str1)
chars = 0
digit = 0
symbols = 0
for i in range(0,len(str1)):
    if (str1[i].isdigit()):
        digit += 1
    elif(str1[i].isalpha()):
        chars += 1
    else:
        symbols += 1
print("chars: ",chars)
print("digit: ",digit)
print("symbols: ",symbols)

#Que7:
l = [1, 7, 3, 5, 2]
l2 = []
for i in range(1,len(l)+1):
    sum = 0
    for j in range(0,i):
        sum = sum + l[j]
    l2.append(sum)
print("list2: ",l2)

#Que8:
n = int(input("Enter a number: "))
s = str(bin(n).replace("0b", ""))
if(s == s[::-1]):
    print("The binary representation of the number is a palindrome.")
else:
    print("The binary representation of the number is not a palindrome.")











        
