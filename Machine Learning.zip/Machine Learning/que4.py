#Create/Define single dimension / multi-dimension arrays, and
#arrays with specific values like array of all ones,
#all zeros, array with random values within a range, or a diagonal matrix.

import numpy as np

arr1 = np.ones(5)
print(arr1)

arr2 = np.zeros(5)
print(arr2)

arr3 = np.random.randint(100, size = (5,3))
print(arr3)
