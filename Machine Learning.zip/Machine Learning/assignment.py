import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


#que1:
df = pd.read_csv("https://gist.githubusercontent.com/fishtai0/5975c7e38c8566b9b3144e45a99b65cf/raw/941a7ecbab78d6032393ba8eed6579a563f126d6/company-sales.csv")
profitList = df ['total_profit'].tolist()
monthList  = df ['month_number'].tolist()
plt.plot(monthList, profitList, label = 'Month-wise Profit data of last year')
plt.xlabel('Month number')
plt.ylabel('Profit in dollar')
plt.xticks(monthList)
plt.title('Company profit per month')
plt.yticks([100000, 200000, 300000, 400000, 500000])
plt.show()

#que2:
df = pd.read_csv("https://gist.githubusercontent.com/fishtai0/5975c7e38c8566b9b3144e45a99b65cf/raw/941a7ecbab78d6032393ba8eed6579a563f126d6/company-sales.csv")
profitList = df ['total_profit'].tolist()
monthList  = df ['month_number'].tolist()

plt.plot(monthList, profitList, label = 'Profit data of last year', 
      color='r', marker='o', markerfacecolor='k', 
      linestyle='--', linewidth=3)
      
plt.xlabel('Month Number')
plt.ylabel('Profit in dollar')
plt.legend(loc='lower right')
plt.title('Company Sales data of last year')
plt.xticks(monthList)
plt.yticks([100000, 200000, 300000, 400000, 500000])
plt.show()

#que3:
plt.subplots(2,2,sharex = "col")
#enables the sybplots to share values accross the columns
plt.subplots(2,2,sharey = "row")
#enables the sybplots to share values accross the rows
plt.subplots(2,2,sharex = "all", sharey = "all")
plt.subplots(2,2,sharex = True, sharey = True)
#3rd 4th enables global sharing accross the whole grid.
plt.show()

#que4:
arr1 = [1, 2, 3, 4, 5]
arr2 = [1, 4, 9, 16, 25]
plt.plot(arr1, arr1, "-b", label="natural numbers")
plt.plot(arr1, arr2, "-r", label="squares")
plt.title("Natural numbers vs their squares")
plt.xlabel("Numbers")
plt.ylabel("Squares")
plt.legend(loc=0)
plt.show()


#que5:
x = np.linspace(0, 10, 100)
plt.plot(x, np.sin(x), "-b", label="sine")
plt.plot(x, np.cos(x), "-r", label="cosine")
plt.title("Sin cos graphs")
plt.xlabel("Angle (in radians)")
plt.ylabel("Value")
plt.legend(loc=0)
plt.show()
