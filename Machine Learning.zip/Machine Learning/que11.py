import numpy as np

m = int(input("Enter number of rows: "))
n = int(input("Enter number of columns: "))

mat1 = np.random.randint(1, 100, size=(m, n))
mat2 = np.random.randint(1, 100, size=(m, n))

print("Adding both matrices...")
print(np.add(mat1, mat2))
   
print("Subtracting second from first...")
print(np.subtract(mat1, mat2))

print("Multiplying matrices...")
print(np.multiply(mat1, mat2))
   
print("Transpose of first matrix: ", mat1.T)
print("Transpose of second matrix: ", mat2.T)
   
print("End of program.")
   
