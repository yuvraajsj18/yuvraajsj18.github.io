import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn import linear_model
import math

#que1
data = pd.read_csv('stock_index.csv')

#part a
plt.xlabel('Interest_rate')
plt.ylabel('Stock_index_price')
plt.scatter(data.Interest_rate, data.Stock_index_price)
plt.show()

#part b
plt.xlabel('Unemployment_rate')
plt.ylabel('Stock_index_price')
plt.scatter(data.Unemployment_rate, data.Stock_index_price)
plt.show()

#part c
median_unemp_rate = math.floor(data.Unemployment_rate.median())
data.Unemployment_rate = data.Unemployment_rate.fillna(median_unemp_rate)

median_int_rate = math.floor(data.Interest_rate.median())
data.Interest_rate = data.Interest_rate.fillna(median_int_rate)

median_sip = math.floor(data.Stock_index_price.median())
data.Stock_index_price = data.Stock_index_price.fillna(median_sip)

reg = linear_model.LinearRegression()
reg.fit(data[['Interest_rate','Unemployment_rate']].values,data.Stock_index_price)

print("Model parameters for created model y = mx + c.")
print("m is: ",reg.coef_)
print("c is: ",reg.intercept_)

#part d 
print("Predicted stock index price if Interest_rate is 2.75 and Unemplyment_rate is 5.3.")
print(reg.predict([[2.75,5.3]]))


#que2
data = pd.read_csv('hiring.csv')
median_experience = 0
data.experience = data.experience.fillna(median_experience)

median_ts = math.floor(data.test_score.median())
data.test_score = data.test_score.fillna(median_ts)

median_is = math.floor(data.interview_score.median())
data.interview_score = data.interview_score.fillna(median_is)

reg = linear_model.LinearRegression()
reg.fit(data[['experience','test_score','interview_score']].values,data.salary)

print("Model parameters for created model y = mx + c.")
print("m is: ",reg.coef_)
print("c is: ",reg.intercept_)

