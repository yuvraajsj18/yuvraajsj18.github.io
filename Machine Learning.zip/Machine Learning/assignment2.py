#Que1:
n = int(input("Enter a number: "))
s = str(bin(n).replace("0b", ""))
count = 0
for i in s:
    if i == '1':
        count += 1
if(count%2 == 0):
    print("Evil Number")
else:
    print("Odious Number")


#Que2:
n = int(input("\nEnter a number: "))
print("Even factors of ",n," are: ")
for i in range(1,n+1):
    if(n%i == 0 and i%2 == 0):
        print(i)


#Que3:
s = input("\nEnter a string: ")
count = {'vowels':0,'consonants':0,'upper':0,'lower':0}
for i in s:
    if(i.isalpha()):
        if(i == 'a' or i == 'e' or i == 'i' or i == 'o' or i == 'u' or i == 'A' or i == 'E' or i == 'I' or i == 'O' or i == 'U'):
            count['vowels'] += 1
        if(not(i == 'a' or i == 'e' or i == 'i' or i == 'o' or i == 'u' or i == 'A' or i == 'E' or i == 'I' or i == 'O' or i == 'U')):
            count['consonants'] += 1
        if(i.isupper()):
            count['upper'] += 1
        if(i.islower()):
            count['lower'] += 1
print("In string: ")
print(count)


#Que4:
n = int(input("\nEnter a number: "))
s = 0
for i in range(1,n+1):
    for j in range(1,i+1):
        s += j
print("Sum of series: [1+(1+2)+(1+2+3)+–+(1+2+3+–+n)] is: ",s)



#Que5:
s = input("\nEnter a string: ")
s2 = 'abcdefghijklmnopqrstuvwxyz'
flag = 0
for i in s2:
    if(i not in s):
        flag = 1
        break
if(flag == 1):
    print("String is not a pangram")
else:
    print("String is a pangram")


#Que6:
s = input("\nEnter a string: ")
print("String: ",s)
l = []
for i in s:
    if(i.isdigit()):
        l.append(int(i))

if(len(l) == 0):
    print("String has no digits")
else:
    print("digits: ",l)
    print("Sum of digits: ",sum(l))


#Que7:
s = input("\nEnter a number: ")
n = 0
for i in s:
    n += int(i)**len(s)
if(int(s) == n):
    print(n, " is an amstrong number")
else:
    print("number is not an amstrong number")



#Que8:
n = int(input("\nEnter a number: "))
print("Pattern: ")
c = 'A'
for i in range(0,n):
    for j in range(0,n-i):
        print(c,end='')
    c = chr(ord(c) + 1)
    print()




