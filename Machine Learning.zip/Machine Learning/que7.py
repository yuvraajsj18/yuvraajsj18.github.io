import numpy as np

m = int(input("Enter number of rows: "))
n = int(input("Enter number of columns: "))

mat = np.random.randint(-100, 100, size=(m, n))
print("Original array\n", mat)

print("Absolute values")
print(np.abs(mat))
    
print("Negation")
print(np.negative(mat))

print("Adding row")
mat = np.append(mat, [np.random.randint(-100, 100, size=(1, n)).flatten()], axis=0)
print(mat)
    
print("Removing row")
r = int(input("Enter row to remove: "))
if 0 <= r <= m:
    mat = np.delete(mat, r, axis=0)
    print(mat)
else:
    print("Index is outside matrix range.")
    
print("Removing column")
c = int(input("Enter column to remove: "))
if 0 <= c <= m:
    mat = np.delete(mat, c, axis=1)
    print(mat)
else:
    print("Index is outside matrix range.")
    
print("Finding max/min from matrix")
print("Max: ", np.max(mat))
print("Min: ", np.min(mat))
    
print("Finding max/min from row")
print("Max: ", np.amax(mat, axis=1))
print("Min: ", np.amin(mat, axis=1))
    
print("Finding max/min from column")
print("Max: ", np.amax(mat, axis=0))
print("Min: ", np.amin(mat, axis=0))
    
print("Finding sum of all elements of matrix")
print(np.sum(mat))
    
print("Finding sum of all elements of a row")
print(np.sum(mat, axis=1))
    
print("Finding sum of all elements of a column")
print(np.sum(mat, axis=0))
   
print("End of program.")
    
        
    
        
