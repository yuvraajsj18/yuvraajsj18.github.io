def getChoice():
    print("1. OR")
    print("2. AND")
    print("3. Check for equality")
    print("4. NOT")
    print("5. XOR")
    print("0. Quit")
    option = int(input("Choice: "))
    return option


n1 = int(input("Enter number 1: "))
n2 = int(input("Enter number 2: "))
choice = getChoice()

while choice != 0:
    if choice == 1:
        print("OR: ", n1 | n2)
    elif choice == 2:
        print("AND: ", n1 & n2)
    elif choice == 3:
        print("Equality Boolean: ", n1 == n2)
    elif choice == 4:
        print("NOT: ", ~n1, ~n2)
    elif choice == 5:
        print("XOR: ", n1 ^ n2)
    choice = getChoice()
