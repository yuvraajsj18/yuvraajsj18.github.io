import numpy as np
import pandas as pd
import matplotlib as plt

dataset = pd.read_csv("Data.csv")
x = dataset.iloc
