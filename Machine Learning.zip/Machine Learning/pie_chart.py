import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

#que1
y = np.array([22.2, 17.6, 8.8, 8, 7.7, 6.7])
mylabels = ['Java', 'Python', 'PHP', 'JavaScript', 'C#', 'C++']
myexplode = [0.1,0,0,0,0,0.2]
plt.pie(y,labels = mylabels, explode = myexplode, startangle = 150, shadow = True, autopct='%1.2f%%')
plt.title("Popularity of programming language worldwide, oct 2017 compared to a year ago")
plt.show()

#Que2
data = pd.read_csv("medal.csv")
plt.pie(data.gold_medal, labels = data.country, autopct='%1.2f%%')
plt.title("gold medal achievements of five most successful countries in 2016 Summer Olympics")
plt.show()
