import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

df = pd.read_csv("HR_comma_sep.csv")
df_left = df.loc[df["left"] > 0]
df_stayed = df.loc[df["left"] == 0]

dummies = pd.get_dummies(df.salary)
merged = pd.concat([df, dummies], axis='columns')
merged.drop(['salary'], axis='columns')

df["Department"] = df["Department"].astype('category').cat.codes

df["salary"] = df["salary"].astype('category').cat.codes

x = df.drop(["left"], axis=1)
x = x.drop(["last_evaluation"], axis=1)
y = df[["left"]].values

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.22, random_state=27)

logReg = LogisticRegression()
logReg.fit(x_train, y_train)
predictions = logReg.predict(x_test)
score = logReg.score(x_test, y_test)
print("Score: ", score)

