import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

df = pd.read_csv("HR_comma_sep.csv")
df_left = df.loc[df["left"] > 0]
df_stayed = df.loc[df["left"] == 0]

# a part
df_salary = df_left['salary'].value_counts()
df_salary = pd.DataFrame(df_salary)
df_salary.columns = ["frequency_left"]
stayed = df_stayed['salary'].value_counts()
stayed = pd.DataFrame(stayed)
df_salary["frequency_stayed"] = stayed["salary"]
df_salary.plot.bar(title="Employees Left vs Employees Stayed by Salary")
plt.show()

# b part
df_dep = df_left['Department'].value_counts()
df_dep = pd.DataFrame(df_dep)
df_dep.columns = ["frequency_left"]
dep_stayed = df_stayed['Department'].value_counts()
dep_stayed = pd.DataFrame(dep_stayed)
df_dep["frequency_stayed"] = dep_stayed["Department"]
df_dep.plot.bar(title="Employees Left vs Employees Stayed by Department")
plt.show()

# c part
dummies = pd.get_dummies(df.salary)
merged = pd.concat([df, dummies], axis='columns')
merged.drop(['salary'], axis='columns')
print(merged)

# d part
df["Department"] = df["Department"].astype('category').cat.codes
df["salary"] = df["salary"].astype('category').cat.codes
x = df.drop(["left"], axis=1)
x = x.drop(["last_evaluation"], axis=1)
y = df[["left"]].values

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.22, random_state=27)
logReg = LogisticRegression()
logReg.fit(x_train, y_train)
predictions = logReg.predict(x_test)
score = logReg.score(x_test, y_test)
print(score)

