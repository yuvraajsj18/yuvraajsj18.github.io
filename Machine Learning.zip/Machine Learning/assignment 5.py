import numpy as np

#a
n = int(input("Enter length : "))
print(np.zeros(n))
print(np.ones(n))
print(np.random.randint(-50,50,n))

#b
n = int(input("Enter number of rows : "))
a = np.random.randint(-50,50,n*n).reshape(n,n)
for i in range(n):
    a[i][i] = 1
print(a)

#c
def menu():
    print("Enter 1 for addition")
    print("Enter 2 for subtraction")
    print("Enter 3 for multiplication")
    print("Enter 4 to exit")

while(True):
    menu()
    c = input("Enter your choice : ")
    row = 0
    col = 0
    a = 0
    b = 0
    if(c == '4'):
        break
    else:
        row = int(input("Enter number of rows : "))
        col = int(input("Enter number of columns : "))
        a = np.random.randint(-50,50,row*col).reshape(row,col)
        b = np.random.randint(-50,50,row*col).reshape(row,col)
        print("first matrix : ")
        print(a)
        print("second matrix : ")
        print(b)
    if(c == '1'):
        print("Resultant matrix :\n",np.add(a,b))
    if(c == '2'):
        print("Resultant matrix :\n",np.subtract(a,b))
    if(c == '3'):
        b.reshape(col,row)
        print("Resultant matrix :\n",np.array([sum([a[i][k]*b[k][j] for k in range(row)]) for i in range(row) for j in range(col)]).reshape(row,row))

#d
n = int(input("Enter number of rows : "))
a = np.random.randint(-50,50,n*n).reshape(n,n)
print("Matrix :\n",a)
print("Determinant : ",np.linalg.det(a))
print("Max in rows : ",[max(a[i]) for i in range(n)])
print("Max in columns : ",[max(a.T[i]) for i in range(n)])
print("Min in rows : ",[min(a[i]) for i in range(n)])
print("Min in columns : ",[min(a.T[i]) for i in range(n)])
print("Sum of matrix : ",sum(sum(a)))
print("Sum of rows : ",[sum(a[i]) for i in range(n)])
print("Sum of columns : ",[sum(a.T[i]) for i in range(n)])
