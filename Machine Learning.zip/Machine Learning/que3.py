x = 5
myString = "Hello World" 
myFormattedString = f"Hello World {x}"

print(x, myString)
print(myFormattedString)
