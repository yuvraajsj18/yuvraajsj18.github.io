def getChoice():
    print("1. Add numbers")
    print("2. Subtract numbers")
    print("3. Multiply numbers")
    print("4. Divide numbers")
    print("5. Exponent")
    print("0. Quit")
    option = int(input("Choice: "))
    return option


n1 = int(input("Enter number 1: "))
n2 = int(input("Enter number 2: "))
choice = getChoice()

while choice != 0:
    if choice == 1:
        print("Sum: ", n1 + n2)
    elif choice == 2:
        print("Difference: ", n1 - n2)
    elif choice == 3:
        print("Product: ", n1 * n2)
    elif choice == 4:
        print("Quotient: ", n1 / n2)
    elif choice == 5:
        print("Exponent: ", n1 ** n2)
    choice = getChoice()
