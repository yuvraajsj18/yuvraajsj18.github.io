from collections import defaultdict
#Que1:
def fact(n):
    f = 2
    for i in range(3,n+1):
        f *= i
    return f

x = int(input("Enter value of x: "))
n = int(input("Enter limit of series(even number): "))
s1 = 1
s2 = 1
count = 1
for i in range(2,n+1,2):
    s1 = s1 + (((-1)**count)*(x**i)/fact(i))
    s2 += ((x**i)/fact(i))
    count += 1
print("Series1  1 – x^2 /2! + x^4 /4! – x^ 6 /6! + … x^n /n! : ",s1)
print("Series2  1 + x^2 /2! + x^4 /4! + x^6 /6! + … x^n /n! : ",s2)


#Que2:
s = input("Enter a sequence of 4 digit binary number: ")
l = s.split(",")
print("Sequence: ",l)
l2 = []
for i in l:
    if(int(i,2)%5 == 0):
        l2.append(i)
print("Numbers divisible by 5 are: ",l2)


#Que3:
d = [i.split(":") for i in input("Enter a elements of dictionary like (a:3,c:1) : ").split(",")]
d = dict([[d[i][0],int(d[i][1])] for i in range(len(d))])
print(d)
d = list(d.items())
for i in range(len(d)-1):
    for j in range(len(d)-1-i):
        if d[j][1]>d[j+1][1]:
            d[j],d[j+1]=d[j+1],d[j]
d = dict(d)
print(d)


#Que4:
A = "apple banana mango"
B = "banana fruits mango"
print("A: ",A,"\n","B: ",B)
l1 = A.split()
l2 = B.split()
l = []
for i in l1:
    if i not in l2:
        l.append(i)
for i in l2:
    if i not in l1:
        l.append(i)

print("uncommon words: ",l)


#Que5:
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
x = bin(a).replace("0b","")
y = bin(b).replace("0b","")
print("Binary representation of ",a," is: ",x)
print("Binary representation of ",b," is: ",y)
if(x.count("1") == y.count("1")):
    print(a," is anagram of ",b)
else:
    print(a," is not an anagram of ",b)



#Que6:
l = [(5, 6), (5, 7), (5, 8), (6, 10), (7, 13)]
print("original dict: ",l)
d = defaultdict(list)
for key,val in l:
    d[key].append(val)
result = [(key, *val) for key,val in d.items()]

print("new list: ",result)        















































