import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

#que1 part a with 10 bins:
age_g1 = [1, 3, 5, 10, 15, 17, 18, 16, 19, 21, 23, 28, 30, 31, 33, 38, 32, 40, 45, 43, 49, 55, 53,
63, 66, 85, 80, 57, 75, 93, 95]
age_g2 = [6, 4, 15, 17, 19, 21, 28, 23, 31, 36, 39, 32, 50, 56, 59, 74, 79, 34, 98, 97, 95, 67,
69, 92, 45, 55, 77, 76, 85]
plt.hist(age_g1,bins = 10, alpha = 0.7, label = 'age group1', edgecolor = 'red')
plt.hist(age_g2,bins = 10, alpha = 0.7, label = 'age group2', edgecolor = 'yellow')
plt.legend(loc = 'upper right')
plt.show()

#que1 part a with 14 bins:
age_g1 = [1, 3, 5, 10, 15, 17, 18, 16, 19, 21, 23, 28, 30, 31, 33, 38, 32, 40, 45, 43, 49, 55, 53,
63, 66, 85, 80, 57, 75, 93, 95]
age_g2 = [6, 4, 15, 17, 19, 21, 28, 23, 31, 36, 39, 32, 50, 56, 59, 74, 79, 34, 98, 97, 95, 67,
69, 92, 45, 55, 77, 76, 85]
plt.hist(age_g1,bins = 14, alpha = 0.7, label = 'age group1', edgecolor = 'red')
plt.hist(age_g2,bins = 14, alpha = 0.7, label = 'age group2', edgecolor = 'yellow')
plt.legend(loc = 'upper right')
plt.show()

#que2:
df = pd.read_csv('iris.csv')
plt.hist(df.sepal_length, alpha = 0.6, label = 'sepal_length', color = 'purple')
plt.hist(df.sepal_width, alpha = 0.8, label = 'sepal_width', color = 'pink')
plt.hist(df.petal_length, alpha = 0.6, label = 'petal_length', color = 'yellow')
plt.hist(df.petal_width, alpha = 0.5, label = 'petal_width', color = 'green')
plt.legend(loc = 'upper right')
plt.show()

#que3:
barWidth = 0.25
fig = plt.subplots(figsize =(12, 8))
IT = [12, 30, 1, 8, 22]
ECE = [28, 6, 16, 5, 10]
CSE = [29, 3, 24, 25, 17]
br1 = np.arange(len(IT))
br2 = [x + barWidth for x in br1]
br3 = [x + barWidth for x in br2]
plt.bar(br1, IT, color ='r', width = barWidth, edgecolor ='grey', label ='IT')
plt.bar(br2, ECE, color ='g', width = barWidth, edgecolor ='grey', label ='ECE')
plt.bar(br3, CSE, color ='b', width = barWidth, edgecolor ='grey', label ='CSE')
plt.xlabel('Branch', fontweight ='bold', fontsize = 15)
plt.ylabel('Students passed', fontweight ='bold', fontsize = 15)
plt.xticks([r + barWidth for r in range(len(IT))], ['2015', '2016', '2017', '2018', '2019'])
plt.legend()
plt.show()

#que4:
N = 5
men = (22, 30, 35, 35, 26)
women = (25, 32, 30, 35, 29)
menStd = (4, 3, 4, 1, 5)
womenStd = (3, 5, 2, 3, 3)
ind = np.arange(N)  
width = 0.35  
fig = plt.subplots(figsize =(10, 7))
p1 = plt.bar(ind, men, width, yerr = menStd, color = 'red')
p2 = plt.bar(ind, women, width, bottom = men, yerr = womenStd, color = 'green')
plt.ylabel('Scores')
plt.title('Scores by group and gender')
plt.xticks(ind, ('Group1', 'Group2', 'Group3', 'Group4', 'Group5'))
plt.yticks(np.arange(0, 81, 10))
plt.legend((p1[0], p2[0]), ('men', 'women'))
plt.show()


#que5:
plt.rcParams["figure.figsize"] = [7.50, 3.50]
plt.rcParams["figure.autolayout"] = True

year = [2014, 2015, 2016, 2017, 2018, 2019]
issues_addressed = [10, 14, 0, 10, 15, 15]
issues_pending = [5, 10, 50, 2, 0, 10]

b1 = plt.barh(year, issues_addressed, color="red")

b2 = plt.barh(year, issues_pending, left=issues_addressed, color="yellow")

plt.legend([b1, b2], ["Completed", "Pending"], title="Issues", loc="upper right")

plt.show()

