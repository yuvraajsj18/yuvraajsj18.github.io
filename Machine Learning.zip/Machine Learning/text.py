import numpy as np
import os

x = np.array([[1, 2, 3], 
              [4, 5, 6],
              [7, 8, 9]], np.int32)

np.savetxt("test.txt", x, fmt="%2.3f", delimiter=",")
y = np.loadtxt("test.txt", delimiter=",")
print(y)


#output:
#[[1. 2. 3.]
# [4. 5. 6.]
# [7. 8. 9.]]

data = np.arange(50, dtype=np.int32)
data.tofile("test2.txt")

fh = open("test2.txt", "rb")
# 4 * 32 = 128
fh.seek(128, os.SEEK_SET)

x = np.fromfile(fh, dtype=np.int32)
print(x)

# output:
# [32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49]
