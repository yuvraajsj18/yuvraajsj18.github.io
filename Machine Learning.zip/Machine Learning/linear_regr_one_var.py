import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn import linear_model
import math

#que1
data = pd.read_csv('canada_per_capita_income.csv')
plt.xlabel('year')
plt.ylabel('per capita income')
plt.scatter(data.year, data.percapita)

median_year = math.floor(data.year.median())
data.year = data.year.fillna(median_year)
median_percapita = math.floor(data.percapita.median())
data.percapita = data.percapita.fillna(median_percapita)

reg = linear_model.LinearRegression()
reg.fit(data[['year']].values,data.percapita)

print("Predicted per capita income for year 2022")
print(reg.predict([[2022]]))
print("Predicted per capita income for year 2027")
print(reg.predict([[2027]]))

print("Model parameters for created model y = mx + c.")
print("m is: ",reg.coef_)
print("c is: ",reg.intercept_)

plt.plot(data.year.values,reg.predict(data[['year']].values))
plt.show()


#que2
data = pd.read_csv('mba_salary.csv')
plt.xlabel('Percentage_in_Grade_10')
plt.ylabel('Salary')
plt.scatter(data.Percentage_in_Grade_10, data.Salary)

reg = linear_model.LinearRegression()
reg.fit(data[['Percentage_in_Grade_10']],data.Salary)
print("Model parameters for created model y = mx + c.")
print("m is: ",reg.coef_)
print("c is: ",reg.intercept_)
plt.plot(data.Percentage_in_Grade_10,reg.predict(data[['Percentage_in_Grade_10']]))
plt.show()
