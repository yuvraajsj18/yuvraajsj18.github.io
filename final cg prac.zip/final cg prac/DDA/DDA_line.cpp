#include<stdio.h>
#include<conio.h>
#include<graphics.h>
#include<math.h>
#include<iostream.h>

void dda_line(float x1,float y1,float x2,float y2)
{
	float dx=x2-x1;
	float dy=y2-y1;
	float x=x1;
	float y=y1;

	if(dx==0)
		for(;y<=y2;y++)
			putpixel(x1,y,WHITE);

	else if(dy==0)
		for(;x<=x2;x++)
			putpixel(x,y1,WHITE);

	else
	{
		float m=dy/dx;
		if(abs(m)<=1)
			for(;x<=x2;x++,y=y+m)
				putpixel(x,int(y+0.5),WHITE);
		else
			for(;y<=y2;y++,x=x+1/m)
				putpixel(int(x+0.5),y,WHITE);
	}
}

void main()
{
	float x1,y1,x2,y2;
	int gd=DETECT, gm;
	clrscr();
	initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
	outtextxy(240,370,"Enter co-ordinates 1 : ");
	gotoxy(53,24);
	cin>>x1>>y1;
	outtextxy(240,390,"Enter co-ordinates 2 : ");
	gotoxy(53,25);
	cin>>x2>>y2;
	dda_line(x1,y1,x2,y2);
	getch();
	closegraph();
}