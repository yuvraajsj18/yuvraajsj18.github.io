range(N1, N2, _) :- N1 > N2, !.
range(N1, N1, [N1]).
range(N1, N2, [N1|L]) :- N3 is N1 + 1, range(N3, N2, L), !.

