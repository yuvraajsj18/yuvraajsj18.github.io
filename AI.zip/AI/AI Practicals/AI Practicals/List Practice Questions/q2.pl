dupli(L, N, X) :- dupli(L, N, X, N), !.
dupli([], _, [], _).
dupli([H|L], N, [H|X], 1) :- dupli(L, N, X, N).
dupli([H|L], N, [H|X], C) :- C =< 0, dupli([H|L], N, X, N).
dupli([H|L], N, [H|X], C) :- C1 is C - 1, dupli([H|L], N, X, C1).
