delete_nth(1, [_H|L], L) :- !.
delete_nth(N, [H|L], [H|R]) :- NN is N-1, delete_nth(NN, L, R).
