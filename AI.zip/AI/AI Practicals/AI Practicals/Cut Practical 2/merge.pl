mergeLists([], L2, L2) :- !.
mergeLists(L1, [], L1) :- !.

mergeLists([H1|L1], [H2|L2], [H1|L3]) :- H1 < H2, mergeLists(L1, [H2|L2], L3), !.
mergeLists([H1|L1], [H2|L2], [H2|L3]) :- mergeLists([H1|L1], L2, L3).

