slice(L, N1, N2, X) :- slice(L, N1, N2, X, 1), !.
slice([_H|_], _N1, N2, _X, C) :- C > N2, !.
slice([H|_], _, N2, [H], N2).
slice([H|L], N1, N2, [H|X], C) :- C >= N1, C1 is C + 1, slice(L, N1, N2, X, C1).
slice([_|L], N1, N2, X, C) :- C < N1, C1 is C + 1, slice(L, N1, N2, X, C1).
