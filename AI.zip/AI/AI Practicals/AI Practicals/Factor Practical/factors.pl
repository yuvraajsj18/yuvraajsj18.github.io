range(I, I, [I]).
range(I, K, [I|L]):- I < K, I1 is I+1, range(I1, K, L).

divisors([],[],_).
divisors([H|T], S, X) :-
    divisors(T, W, X),
    Z is X mod H,
    (Z==0->S=[H|W]; S=W).

div(X, Res) :- range(1, X, Res1), divisors(Res1, Res, X).
