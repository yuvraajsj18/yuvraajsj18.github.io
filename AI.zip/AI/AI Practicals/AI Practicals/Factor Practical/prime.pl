isPrime(2) :-!.
isPrime(3) :- !.
isPrime(X) :- X > 3, X mod 2 =\= 0, isPrime_(X, 3).

isPrime_(X, N):- (
    N*N > X -> true;
    X mod N =\= 0, M is N+2, isprime_(X, M)
).
