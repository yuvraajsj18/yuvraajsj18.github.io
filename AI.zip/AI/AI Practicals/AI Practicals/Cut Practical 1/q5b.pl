f(X) :- X = p, !.
f(X) :- X = q, !.
f(X) :- X = r.
