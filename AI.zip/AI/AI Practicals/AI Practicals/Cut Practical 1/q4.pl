split([], [], []).

split([HL|TL], [HL|Positives], Negatives) :- HL >= 0, split(TL, Positives, Negatives), !.
split([HL|TL], Positives, [HL|Negatives]) :- HL < 0, split(TL, Positives, Negatives).
