start:- read(X), cube(X).
cube(X):- C is X^3, write("Cube of "), write(X), write(" is "), write(C).

