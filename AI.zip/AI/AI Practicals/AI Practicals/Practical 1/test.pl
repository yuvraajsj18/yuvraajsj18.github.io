parent(pam, bob).
parent(bob, liz).

