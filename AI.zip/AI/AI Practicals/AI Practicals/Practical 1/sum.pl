start:- read(X), read(Y), sum(X, Y).
sum(X, Y):- S is X+Y, write("Sum of "), write(X), write(" and "), write(Y), write(" is "), write(S).

