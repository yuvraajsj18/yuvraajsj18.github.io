find_last([H], E) :- E is H.
find_last([_H|T], E) :- find_last(T, E).
