prodlist([], 1).
prodlist([H], H).
prodlist([H|T], P) :- prodlist(T, P1), P is P1 * H.
