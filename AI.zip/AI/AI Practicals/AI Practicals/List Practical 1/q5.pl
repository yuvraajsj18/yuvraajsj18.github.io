sumlist1([], 0).
sumlist1([H], H).
sumlist1([H|T], S) :- sumlist1(T, S1), S is S1 + H.

leng([], 0).
leng([_H|T], N) :- leng(T, L), N is L + 1.

averageList(L, M) :- sumlist1(L, S), leng(L, N), M is S/N.
