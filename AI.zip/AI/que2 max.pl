start:-write("Enter first value: "),read(X),write("Enter second value: "),read(Y),
    greater(X,Y).
greater(X,Y):- X>Y,write(X),write(" is greater than "),write(Y).
greater(X,Y):- Y>X,write(Y),write(" is greater than "),write(X).

max(X, Y, M):- X >= Y, M is X; X < Y, M is Y.
