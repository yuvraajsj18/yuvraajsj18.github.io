#include<stdio.h>
#include<conio.h>
#include<graphics.h>
#include<math.h>
#include<iostream.h>
void mid_point_line(float x1,float y1,float x2,float y2,int
midx,int midy){
float dx = x2-x1;
float dy = y2-y1;
float x=x1;
float y=y1;
if(dy<=dx){
int d = dy-(dx/2);
while(x++<x2) {
if(d<0)
d += dy;
else {
d += (dy-dx);
y++;
}
putpixel(x+midx,-y+midy,WHITE);
}
}
else {
int d = dx-(dy/2);
while(y++<y2) {
if(d<0)
d += dx;
else {
d += (dx-dy);
x++;
}
putpixel(x+midx,-y+midy,WHITE);
}
}
}
void main()
{
float x1,y1,x2,y2;
int gd=DETECT, gm;
clrscr();
initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
int maxx = getmaxx();
int maxy = 350;
int midx = (int)(maxx/2);
int midy = (int)(maxy/2);
line(midx,10,midx,maxy);
line(0,midy,maxx,midy);
outtextxy(240,370,"Enter co-ordinates 1 : ");
gotoxy(53,24);
cin>>x1>>y1;
outtextxy(240,390,"Enter co-ordinates 2 : ");
gotoxy(53,25);
cin>>x2>>y2;
mid_point_line(x1,y1,x2,y2,midx,midy);
getch();
closegraph();
}