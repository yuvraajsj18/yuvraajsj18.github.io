library(arules)

#Solving for Market_Basket.csv
db <- read.transactions("Market_Basket.csv", sep=",", rm.duplicate=TRUE)
db
summary(db)

freq_is <- apriori(db, parameter = list(target = "frequent itemsets", support = 0.05))
freq_is

rules = apriori(data = db, parameter = list(support = 0.05, confidence = 0.1))
rules
inspect(rules)


#Solving for 1000-out1.csv
db <- read.transactions("1000-out1.csv", sep=",", rm.duplicate=TRUE)
db
summary(db)

freq_is <- apriori(db, parameter = list(target = "frequent itemsets", support = 0.08))
freq_is

rules = apriori(data = db, parameter = list(support = 0.08, confidence = 0.09))
rules
inspect(rules)