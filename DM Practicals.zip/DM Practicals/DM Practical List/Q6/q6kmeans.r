library(xlsx)
library(ggplot2)
library(caret)

#Solving for perfume
df <- read.xlsx("perfume_data.xlsx", 1, header=FALSE)
df

df2 <- df[2:29]
df2

km <- kmeans(df2, 4)

df$cluster<-factor(km$cluster)
df

centers<-data.frame(cluster=factor(1:4),km$centers)
centers

ggplot(data=df, aes(x=X2, y=X3, shape=cluster, color=cluster))+
  geom_point(alpha=0.2)+
  geom_point(data=centers,aes(x=X2,y=X3),size=3,stroke=2)


#Solving for HTRU_2
df <- read.csv("HTRU_2.csv", header=FALSE)
df

df2 <- df[1:8]
df2

km <- kmeans(df2, 4)

df$cluster<-factor(km$cluster)
df

centers<-data.frame(cluster=factor(1:5),km$centers)
centers

ggplot(data=df, aes(x=X2, y=X3, shape=cluster, color=cluster))+
  geom_point(alpha=0.2)+
  geom_point(data=centers,aes(x=X2,y=X3),size=3,stroke=2)

