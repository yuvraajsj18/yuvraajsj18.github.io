library(caret)
library(RWeka)
library(klaR)


#Solving for breast cancer wisconsin data
bcw <- read.csv("breast_cancer_data.csv")
bcw <- subset(bcw, select = -X)

trainIndex <- createDataPartition(bcw$diagnosis, p=0.75, list=FALSE)
bcwTrain <- bcw[trainIndex, ]
bcwTest <- bcw[-trainIndex, ]

fitControl <- trainControl(method="cv", number = 10)
knnModel <- train(diagnosis~., bcwTrain, method="knn", trControl=fitControl)

knnPredictions <- predict(knnModel, bcwTest)

knnResult <- confusionMatrix(knnPredictions, as.factor(bcwTest$diagnosis))
knnAcc <- knnResult$overall[['Accuracy']]

NBModel <- train(diagnosis~., bcwTrain, method="nb", trControl=fitControl)

NBPredictions <- predict(NBModel, bcwTest)

NBResult <- confusionMatrix(NBPredictions, as.factor(bcwTest$diagnosis))
NBAcc <- NBResult$overall[['Accuracy']]

DTModel <- train(diagnosis~., bcwTrain, method="J48", trControl=fitControl)

DTPredictions <- predict(DTModel, bcwTest)

DTResult <- confusionMatrix(DTPredictions, as.factor(bcwTest$diagnosis))
DTAcc <- DTResult$overall[['Accuracy']]

x <- c("KNN", "Naive Bayes", "Decision Tree")
y <- c(knnAcc, NBAcc, DTAcc)
qplot(x, y, xlab="Classifier", ylab="Accuracy")


#After Standardization
bcw <- read.csv("data.csv")
bcw <- subset(bcw, select = -X)


processParams <- preProcess(bcw[3:32],method = c("scale","center"))
bcw[3:32] <- predict(processParams, bcw[3:32])

trainIndex <- createDataPartition(bcw$diagnosis, p=0.75, list=FALSE)
bcwTrain <- bcw[trainIndex, ]
bcwTest <- bcw[-trainIndex, ]

fitControl <- trainControl(method="cv", number = 10)
knnModel <- train(diagnosis~., bcwTrain, method="knn", trControl=fitControl)

knnPredictions <- predict(knnModel, bcwTest)

knnResult <- confusionMatrix(knnPredictions, as.factor(bcwTest$diagnosis))
knnAcc <- knnResult$overall[['Accuracy']]

NBModel <- train(diagnosis~., bcwTrain, method="nb", trControl=fitControl)

NBPredictions <- predict(NBModel, bcwTest)

NBResult <- confusionMatrix(NBPredictions, as.factor(bcwTest$diagnosis))
NBAcc <- NBResult$overall[['Accuracy']]

DTModel <- train(diagnosis~., bcwTrain, method="J48", trControl=fitControl)

DTPredictions <- predict(DTModel, bcwTest)

DTResult <- confusionMatrix(DTPredictions, as.factor(bcwTest$diagnosis))
DTAcc <- DTResult$overall[['Accuracy']]

x <- c("KNN", "Naive Bayes", "Decision Tree")
y <- c(knnAcc, NBAcc, DTAcc)
qplot(x, y, xlab="Classifier", ylab="Accuracy")



#Solving for Abalone
abalone <- read.csv("abalone.csv")
abalone

trainIndex <- createDataPartition(abalone$Sex, p=0.75, list=FALSE)
abaloneTrain <- abalone[trainIndex, ]
abaloneTest <- abalone[-trainIndex, ]

fitControl <- trainControl(method="cv", number = 10)
knnModel <- train(Sex~., abaloneTrain, method="knn", trControl=fitControl)

knnPredictions <- predict(knnModel, abaloneTest)

knnResult <- confusionMatrix(knnPredictions, as.factor(abaloneTest$Sex))
knnAcc <- knnResult$overall[['Accuracy']]

NBModel <- train(Sex~., abaloneTrain, method="nb", trControl=fitControl)

NBPredictions <- predict(NBModel, abaloneTest)

NBResult <- confusionMatrix(NBPredictions, as.factor(abaloneTest$Sex))
NBAcc <- NBResult$overall[['Accuracy']]

DTModel <- train(Sex~., abaloneTrain, method="J48", trControl=fitControl)

DTPredictions <- predict(DTModel, abaloneTest)

DTResult <- confusionMatrix(DTPredictions, as.factor(abaloneTest$Sex))
DTAcc <- DTResult$overall[['Accuracy']]

x <- c("KNN", "Naive Bayes", "Decision Tree")
y <- c(knnAcc, NBAcc, DTAcc)
qplot(x, y, xlab="Classifier", ylab="Accuracy")



#After standardization
abalone <- read.csv("abalone.csv")
abalone

processParams <- preProcess(abalone[2:9],method = c("scale","center"))
abalone[2:9] <- predict(processParams, abalone[2:9])


trainIndex <- createDataPartition(abalone$Sex, p=0.75, list=FALSE)
abaloneTrain <- abalone[trainIndex, ]
abaloneTest <- abalone[-trainIndex, ]

fitControl <- trainControl(method="cv", number = 10)
knnModel <- train(Sex~., abaloneTrain, method="knn", trControl=fitControl)

knnPredictions <- predict(knnModel, abaloneTest)

knnResult <- confusionMatrix(knnPredictions, as.factor(abaloneTest$Sex))
knnAcc <- knnResult$overall[['Accuracy']]

NBModel <- train(Sex~., abaloneTrain, method="nb", trControl=fitControl)

NBPredictions <- predict(NBModel, abaloneTest)

NBResult <- confusionMatrix(NBPredictions, as.factor(abaloneTest$Sex))
NBAcc <- NBResult$overall[['Accuracy']]

DTModel <- train(Sex~., abaloneTrain, method="J48", trControl=fitControl)

DTPredictions <- predict(DTModel, abaloneTest)

DTResult <- confusionMatrix(DTPredictions, as.factor(abaloneTest$Sex))
DTAcc <- DTResult$overall[['Accuracy']]

x <- c("KNN", "Naive Bayes", "Decision Tree")
y <- c(knnAcc, NBAcc, DTAcc)
qplot(x, y, xlab="Classifier", ylab="Accuracy")
