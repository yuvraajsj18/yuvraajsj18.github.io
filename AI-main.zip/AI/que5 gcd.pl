gcd(0, B, X):- X = B, !.
gcd(A, 0, X):- X = A, !.
gcd(A, B, X):- A > B, !, gcd(B, A, X).

gcd(A, B, X):-
A < B,
T is B mod A,
gcd(A, T, X).
