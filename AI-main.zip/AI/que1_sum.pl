start:-write("Enter first value: "),read(X),write("Enter second value: "),read(Y),
    sum(X,Y).
sum(X,Y):- S is X+Y, write("Sum of "),write(X),write(" and "),write(Y),write(" is"),
    write(S).


