%8. Write a Prolog program to implement memb(X, L): to check whether X
% is a member of L or not.
memb(X,[X|_Tail]).
memb(X,[_Head|Tail]):- memb(X,Tail).


% 9.Write a Prolog program to implement conc (L1, L2, L3) where L2 is
% the list to be appended with L1 to get the resulted list L3.
conc([],L,L).
conc([_X|L1],L2,[_X|L3]):-conc(L1,L2,L3).

% 10. Write a Prolog program to implement reverse (L, R) where List L is
% original and List R is reversed list.
append([],L,L).
append([_X|L1],L2,[_X|L3]):- append(L1,L2,L3).
reverse([],[]).
reverse([H|T],R):- reverse(T,L1),append(L1,[H],R).


% 11. Write a program in PROLOG to implement palindrome (L) which checks
% whether a list L is a palindrome or not.
app([],L,L).
app([_X|L1],L2,[_X|L3]):- app(L1,L2,L3).
pal([]).
pal([_]).
pal(Plist):-app([H|T],[H],Plist),pal(T).


% 12. Write a Prolog program to implement sumlist(L, S) so that S is the
% sum of a given list L.
sumlist([],0).
sumlist([H|T],S):-sumlist(T,S1),S is H+S1.

% 13. Write a Prolog program to implement two predicates evenlen(List)
% and oddlen(List) so that they are true if their argument is a list of
% even or odd length respectively
evelen([]).
evelen([_|[_|List]]):-evelen(List).
oddlen([_]).
oddlen([_|[_|List]]):-oddlen(List).


% 14. Write a Prolog program to implement nth_element (N, L, X) where N
% is the desired position, L is a list and X represents the Nth element
% of L.
nth_element(1,[H|T],H).
nth_element(N,[H|T],X):-N1 is N-1,nth_element(N1,T,X).


% 15. Write a Prolog program to implement maxlist(L, M) so that M is
% the maximum number in the list
max(X,Y,Z):- X>Y,Z is X.
max(X,Y,Z):- X=<Y,Z is Y.
maxlist([],0):-!.
maxlist([R],R):-!.
maxlist([H|T],R):-maxlist(T,R1),max(H,R1,R),!.


% 16. Write a prolog program to implement insert_nth(I, N, L, R) that
% inserts an item I into Nth position of list L to generate a list R.
insertn(Item,List,1,[Item|List]).
insertn(Item,[H|List],Pos,[H|Result]):-Pos1 is Pos-1,insertn(Item,List,Pos1,Result).


% 17. Write a Prolog program to implement delete_nth (N, L, R) that
% removes the element on Nth position from a list L to generate a list
% R.
removen([_|List],1,List).
removen([H|List],Pos,[H|Result]):-Pos1 is Pos-1, removen(List,Pos1,Result).


% 18. Write a program in PROLOG to implement merge (L1, L2, L3) where L1
% is first ordered list and L2 is second ordered list and L3 represents
% the merged list.
merge(X,[],X).
merge([],Y,Y).
merge([X|X1],[Y|Y1],[X|Z]):-X<Y,!,merge(X1,[Y|Y1],Z).
merge([X|X1],[Y|Y1],[X,Y|Z]):-X=Y,!,merge(X1,Y1,Z).
merge([X|X1],[Y|Y1],[Y|Z]):-X>Y,!,merge([X|X1],Y1,Z).










