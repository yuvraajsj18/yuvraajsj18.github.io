print_all([]) :- write("End of list").
print_all([H|T]) :- write(H), write('\n'), print_all(T).
