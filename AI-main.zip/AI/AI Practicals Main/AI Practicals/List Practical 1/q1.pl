memb(X, [X|_T]) :- !.
memb(X, [_Y|T]) :- memb(X, T).

