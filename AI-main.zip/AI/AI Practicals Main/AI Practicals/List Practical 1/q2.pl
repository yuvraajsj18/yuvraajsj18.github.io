sumlist1([], 0).
sumlist1([H], H).
sumlist1([H|T], S) :- sumlist1(T, S1), S is S1 + H.
