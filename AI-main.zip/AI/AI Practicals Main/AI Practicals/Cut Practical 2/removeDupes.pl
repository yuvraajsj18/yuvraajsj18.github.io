memb(X, [X|_T]) :- !.
memb(X, [_Y|T]) :- memb(X, T).

removeDuplicates([], []) :- !.
removeDuplicates([H|L], R) :- memb(H, L), removeDuplicates(L, R), !.
removeDuplicates([H|L], [H|R]) :- removeDuplicates(L, R).


