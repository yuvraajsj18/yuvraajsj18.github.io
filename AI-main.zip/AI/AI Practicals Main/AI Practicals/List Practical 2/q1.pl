leng([], 0).
leng([_H|T], N) :- leng(T, L), N is L + 1.
