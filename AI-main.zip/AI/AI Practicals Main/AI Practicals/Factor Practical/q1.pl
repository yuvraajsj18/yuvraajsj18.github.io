ins_tail([], N, [N]).
ins_tail([H|T], N, [H|R]) :- ins_tail(T, N, R).

factors(P, F) :-
    L is [1],
    P > 1 ->
      (Z is  P mod F, Z == 0 ->
        ins_tail(F, [L], L),
        P1 is P/F,
        factors(P1, 2) ;
       F1 is F + 1,
       factors(P, F1)) ;
    write(L).

