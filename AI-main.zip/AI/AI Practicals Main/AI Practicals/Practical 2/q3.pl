power(Num, Pow, Ans) :- Ans is Num^Pow.

