memb(X, [X|_T]) :- !.
memb(X, [_Y|T]) :- memb(X, T).

add(X, L, _L1) :- memb(X, L), !.
add(X, L, [X|L]).

