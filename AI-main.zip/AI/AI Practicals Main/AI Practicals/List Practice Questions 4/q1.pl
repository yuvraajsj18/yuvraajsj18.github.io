even(L) :- !, even(L, 0).
even([], C) :- write(C).
even([H|L], C) :- Z is H mod 2, Z == 0, C1 is C + 1, even(L, C1), !.
even([_H|L], C) :- even(L, C).
