ascending([H|L]) :- ascending(L, H).
ascending([], _) :- true.
ascending([H|L], X) :- X < H, ascending(L, H).
